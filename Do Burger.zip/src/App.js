import Main from './Components/Main';
import './CSS/App.css';

function App() {
  return (
    <div className="App">
      <Main />
    </div>
    
  );
}

export default App;
