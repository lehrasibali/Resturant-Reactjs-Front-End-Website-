
export const LunchData = [
        {
          "id": "61050f211ab57ba6cd86b1e8",
          'num' : 1,
          "name": "Lahori Chikar Cholay",
          "type": 'LUNCH',
          "desc" : 'Bowl Of Chikkar Choly Served with Roti Naan',
          "imgSrc" : 'https://static.sooperchef.pk/topics/2023/05/lahori-chikar-cholay-recipe-550x375.png'
        },
        {
          "id": "61050f21aa707624a853421b",
          'num' : 2,
          "name": "Daal Mash Dhaba Style",
          "type": 'LUNCH',
          "desc" : 'Dhaba Style Daal with Makhan Topping Served with Nan/ Roti',
          "imgSrc" : 'https://static.sooperchef.pk/topics/2023/05/daal-mash-dhaba-style-recipe-550x375.png'
        },
        {
          "id": "61050f21ec0c4d434eedda85",
          'num' : 3,
          "name": "Moong Daal Tadka",
          "type": 'LUNCH',
          "desc" : 'Mong Daal Served With Roti Naan',
          "imgSrc" : 'https://static.sooperchef.pk/topics/2023/02/moong-daal-tadka-recipe-550x375.jpg'
        },
        {
          "id": "61050f21a4543be9235f4643",
          'num' : 4,
          "name": "Chana Pulao with Kabab Tikki",
          "type": 'LUNCH',
          "desc" : 'Platter of Pulao Served with Kabab Tikki and Raita',
          "imgSrc" : "https://static.sooperchef.pk/topics/2023/02/chana-pulao-with-kabab-tikki-masala-recipe-550x375.jpg"
        },
        {
          "id": "61050f21ec0c4d434eedda85",
          'num' : 5,
          "name": "White Chicken Karahi",
          "type": 'LUNCH',
          "desc" : "White Chiken Karahi Per KG Served for 4 pople",
          "imgSrc" : "https://static.sooperchef.pk/topics/2023/05/white-chicken-karahi-recipe-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4643",
          'num' : 6,
          "name": "Kadhi Pakora",
          "type": 'LUNCH',
          "desc" : 'Bowl Of Kadhi Pakora Served with Roti Naan',
          "imgSrc" : "https://static.sooperchef.pk/topics/2023/01/punjabi-style-kadhi-pakora-recipe-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4644",
          'num' : 7,
          "name": "Shahi Haleem with Nuts Pulao",
          "type": 'LUNCH',
          "desc" : 'Shahi Haleem With Extra Topping Of Nuts with EXtra plate of Rice.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2022/11/shahi-haleem-with-nuts-pulao-recipe-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4645",
          'num' : 8,
          "name": "Kalay Chanay Ka Pulao",
          "type": 'LUNCH',
          "desc" : 'Desi Home made Channa Pulao with Kally Channy',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/10/kalay-chanay-ka-pulao-recipe-550x375.jpg"
        }
        
    ];