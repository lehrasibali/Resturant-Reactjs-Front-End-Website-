export const DessertsData = [
    {
      "id": "61050f21",
      'num' : 1,
      "name": "Kheer with Meetha Poora",
      "type": 'DESERT',
      "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
      "imgSrc" : 'https://static.sooperchef.pk/topics/2023/02/kheer-with-meetha-poora-recipe-550x375.jpg'
    },
    {
      "id": "61050f22",
      'num' : 2,
      "name": "Besan ka Halwa",
      "type": 'DESERT',
      "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
      "imgSrc" : 'https://static.sooperchef.pk/topics/2023/01/besan-ka-halwa-recipe-550x375.jpg'
    },
    {
      "id": "61050f23",
      'num' : 3,
      "name": "Chocolate Falooda",
      "type": 'DESERT',
      "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
      "imgSrc" : 'https://static.sooperchef.pk/topics/2022/05/chocolate-falooda-recipe-550x375.jpg'
    }
];