export const allData = [
  {
    "id": "61050f211ab57ba6cd86b1e8",
    'num' : 1,
    "name": "Anda Tikki",
    "type": 'Dinner',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2020/10/anda-tikki-recipe-550x375.jpg"
  },
  {
    "id": "61050f21aa707624a853421b",
    'num' : 2,
    "name": "Lahori Chargha",
    "type": 'Dinner',
    "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2020/10/lahori-chargha-recipe-550x375.jpg"
  },
  {
    "id": "61050f21ec0c4d434eedda85",
    'num' : 3,
    "name": "Hyderabadi Mutton Biryani",
    "type": 'Dinner',
    "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2019/08/hyderabadi-biryani-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f4643",
    'num' : 4,
    "name": "Aloo Palak",
    "type": 'Dinner',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2020/02/aloo_palak-550x375.jpg"
  },
  {
    "id": "61050f21ec0c4d434eedda85",
    'num' : 5,
    "name": "Aloo Gosht",
    "type": 'Dinner',
    "desc" : "This above all: to thine own self be trueAnd it must follow, as the night the day.",
    "imgSrc" : "https://static.sooperchef.pk/topics/2019/05/aloo-gosht-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f4643",
    'num' : 6,
    "name": "Aloo Matar",
    "type": 'Dinner',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2019/03/aloo-matar-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f46444",
    'num' : 7,
    "name": "Chawal Chole",
    "type": 'Dinner',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2019/03/chana-chawal-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f4647",
    'num' : 8,
    "name": "Baingan Gosht",
    "type": 'Dinner',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2018/12/baingan-gosht-550x375.jpg"
  },
  {"id": "61050f21a4543be9235f4649",
  'num' : 9,
  "name": "Lahori Fish Fry",
  "type": 'Dinner',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2018/11/lahori-fish-fry-550x375.jpg"
},

{"id": "61050f21a4543be9235f4648",
'num' : 10,
"name": "Beef Pulao",
"type": 'Dinner',
"desc" : 'If more of us valued food and cheer and song above hoarded gold.',
"imgSrc" : "https://static.sooperchef.pk/topics/2018/04/Beef-Pulao-Recipe-550x375.png"
},
{
  "id": "11",
  'num' : 11,
  "name": "Desi Ghee Ki Choori",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2023/05/desi-ghee-ki-choori-recipe-550x375.jpg"
},
{
  "id": "61050f211ab57ba6cd86b1e8",
  'num' : 12,
  "name": "Chatpata Tawa Chicken with Lacha Paratha",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2022/04/chatpata-tawa-chicken-with-lacha-paratha-recipe-550x375.jpg"
},
{
  "id": "61050f21aa707624a853421b",
  'num' : 13,
  "name": "Halwa Puri with Aloo Chanay",
  "type": 'Breakfast',
  "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2022/01/halwa-puri-with-aloo-chanay-recipe-550x375.jpg"
},
{
  "id": "61050f21a4543be9235f4643",
  'num' : 14,
  "name": "Cake Rusk with Chai",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2023/02/easy-homemade-cake-rusk-recipe-550x375.jpg"
},
{
  "id": "61050f21ec0c4d434eedda85",
  'num' : 15,
  "name": "Chinese Paratha",
  "type": 'Breakfast',
  "desc" : "This above all: to thine own self be trueAnd it must follow, as the night the day.",
  "imgSrc" : "https://static.sooperchef.pk/topics/2021/02/chinese-paratha-recipe-550x375.jpg"
},
{
  "id": "61050f21a4543be9235f4643",
  'num' : 16,
  "name": "Lachay Dar Qeema Paratha",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2020/08/lachy-dar-qeema-paratha-1-550x375.jpg"
},
{
  "id": "61050f21a4543be9235f4644",
  'num' : 17,
  "name": "Anda Chanay",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2020/07/anda_chanay_recipe-550x375.jpg"
},
{
  "id": "61050f21a4543be9235f4645",
  'num' : 18,
  "name": "Lahori Murgh Cholay",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2020/03/lahori-murgh-choly-550x375.jpg"
},
{
  "id": "61050f21a4543be9235f4646",
  'num' : 19,
  "name": "Bread omelette",
  "type": 'Breakfast',
  "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
  "imgSrc" : "https://static.sooperchef.pk/topics/2020/03/bread-omelette-recipe-550x375.jpg"},
  {
    "id": "61050f211ab57ba6cd86b1e8",
    'num' : 20,
    "name": "Lahori Chikar Cholay",
    "type": 'LUNCH',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : 'https://static.sooperchef.pk/topics/2023/05/lahori-chikar-cholay-recipe-550x375.png'
  },
  {
    "id": "61050f21aa707624a853421b",
    'num' : 21,
    "name": "Daal Mash Dhaba Style",
    "type": 'LUNCH',
    "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
    "imgSrc" : 'https://static.sooperchef.pk/topics/2023/05/daal-mash-dhaba-style-recipe-550x375.png'
  },
  {
    "id": "61050f21ec0c4d434eedda85",
    'num' : 22,
    "name": "Moong Daal Tadka",
    "type": 'LUNCH',
    "desc" : 'There are people in the world so hungry, that God cannot appear to them.',
    "imgSrc" : 'https://static.sooperchef.pk/topics/2023/02/moong-daal-tadka-recipe-550x375.jpg'
  },
  {
    "id": "61050f21a4543be9235f4643",
    'num' : 23,
    "name": "Chana Pulao with Kabab Tikki",
    "type": 'LUNCH',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2023/02/chana-pulao-with-kabab-tikki-masala-recipe-550x375.jpg"
  },
  {
    "id": "61050f21ec0c4d434eedda85",
    'num' : 24,
    "name": "White Chicken Karahi",
    "type": 'LUNCH',
    "desc" : "This above all: to thine own self be trueAnd it must follow, as the night the day.",
    "imgSrc" : "https://static.sooperchef.pk/topics/2023/05/white-chicken-karahi-recipe-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f4643",
    'num' : 25,
    "name": "Kadhi Pakora",
    "type": 'LUNCH',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2023/01/punjabi-style-kadhi-pakora-recipe-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f4644",
    'num' : 26,
    "name": "Shahi Haleem with Nuts Pulao",
    "type": 'LUNCH',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2022/11/shahi-haleem-with-nuts-pulao-recipe-550x375.jpg"
  },
  {
    "id": "61050f21a4543be9235f4645",
    'num' : 27,
    "name": "Kalay Chanay Ka Pulao",
    "type": 'LUNCH',
    "desc" : 'If more of us valued food and cheer and song above hoarded gold.',
    "imgSrc" : "https://static.sooperchef.pk/topics/2020/10/kalay-chanay-ka-pulao-recipe-550x375.jpg"
  }
    ];