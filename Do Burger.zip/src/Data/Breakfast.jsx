export const BreakfastData = [
         {
          "id": "11",
          'num' : 1,
          "name": "Desi Ghee Ki Choori",
          "type": 'Breakfast',
          "desc" : 'Served With Cup of Tea ',
          "imgSrc" : "https://static.sooperchef.pk/topics/2023/05/desi-ghee-ki-choori-recipe-550x375.jpg"
        },
        {
          "id": "61050f211ab57ba6cd86b1e8",
          'num' : 2,
          "name": "Chatpata Tawa Chicken with Lacha Paratha",
          "type": 'Breakfast',
          "desc" : 'Served With 2 Paratha.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2022/04/chatpata-tawa-chicken-with-lacha-paratha-recipe-550x375.jpg"
        },
        {
          "id": "61050f21aa707624a853421b",
          'num' : 3,
          "name": "Halwa Puri with Aloo Chanay",
          "type": 'Breakfast',
          "desc" : 'Desi Taste Served With Bowl of Halwa Channy and Aloo .',
          "imgSrc" : "https://static.sooperchef.pk/topics/2022/01/halwa-puri-with-aloo-chanay-recipe-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4643",
          'num' : 4,
          "name": "Cake Rusk with Chai",
          "type": 'Breakfast',
          "desc" : 'Served with Cup of Tea and Home made Cake Rus.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2023/02/easy-homemade-cake-rusk-recipe-550x375.jpg"
        },
        {
          "id": "61050f21ec0c4d434eedda85",
          'num' : 5,
          "name": "Chinese Paratha",
          "type": 'Breakfast',
          "desc" : "Desi Paratha With Cheesy and Tasty Touch.",
          "imgSrc" : "https://static.sooperchef.pk/topics/2021/02/chinese-paratha-recipe-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4643",
          'num' : 6,
          "name": "Lachay Dar Qeema Paratha",
          "type": 'Breakfast',
          "desc" : 'Paratha With Bowl of Qeema.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/08/lachy-dar-qeema-paratha-1-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4644",
          'num' : 7,
          "name": "Anda Chanay",
          "type": 'Breakfast',
          "desc" : 'Lahori Channy Served with Boil Anda and Paratha',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/07/anda_chanay_recipe-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4645",
          'num' : 8,
          "name": "Lahori Murgh Cholay",
          "type": 'Breakfast',
          "desc" : 'Lahori Murgh Channy Served with 2 Paratha',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/03/lahori-murgh-choly-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4646",
          'num' : 9,
          "name": "Bread omelette",
          "type": 'Breakfast',
          "desc" : 'Slice of Bread With Fry Omelette With enrich Cheese Tooings.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/03/bread-omelette-recipe-550x375.jpg"}
    ];