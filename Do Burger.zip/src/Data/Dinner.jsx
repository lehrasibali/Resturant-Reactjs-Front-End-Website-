export const DinnerData = [
        {
          "id": "61050f211ab57ba6cd86b1e8",
          'num' : 1,
          "name": "Anda Tikki",
          "type": 'Dinner',
          "desc" : 'Anda Tikki Served With Naan & Roti.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/10/anda-tikki-recipe-550x375.jpg"
        },
        {
          "id": "61050f21aa707624a853421b",
          'num' : 2,
          "name": "Lahori Chargha",
          "type": 'Dinner',
          "desc" : 'Chargha For 4 People Served with Roti/Naan.',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/10/lahori-chargha-recipe-550x375.jpg"
        },
        {
          "id": "61050f21ec0c4d434eedda85",
          'num' : 3,
          "name": "Hyderabadi Mutton Biryani",
          "type": 'Dinner',
          "desc" : 'Platter of Biryani with Piece of Choice',
          "imgSrc" : "https://static.sooperchef.pk/topics/2019/08/hyderabadi-biryani-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4643",
          'num' : 4,
          "name": "Aloo Palak",
          "type": 'Dinner',
          "desc" : 'Bowl of Aloo Palak Served with Roti/Naan',
          "imgSrc" : "https://static.sooperchef.pk/topics/2020/02/aloo_palak-550x375.jpg"
        },
        {
          "id": "61050f21ec0c4d434eedda85",
          'num' : 5,
          "name": "Aloo Gosht",
          "type": 'Dinner',
          "desc" : "Bowl of Aloo Gosht Served With 6 Roti Naan",
          "imgSrc" : "https://static.sooperchef.pk/topics/2019/05/aloo-gosht-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4643",
          'num' : 6,
          "name": "Aloo Matar",
          "type": 'Dinner',
          "desc" : 'Bowl Of Aloo Matar With Naan/Roti',
          "imgSrc" : "https://static.sooperchef.pk/topics/2019/03/aloo-matar-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f46444",
          'num' : 7,
          "name": "Chawal Chole",
          "type": 'Dinner',
          "desc" : 'Bowl oof Boil Rice with Chole of Choice',
          "imgSrc" : "https://static.sooperchef.pk/topics/2019/03/chana-chawal-550x375.jpg"
        },
        {
          "id": "61050f21a4543be9235f4647",
          'num' : 8,
          "name": "Baingan Gosht",
          "type": 'Dinner',
          "desc" : 'Baigaan Bhujiya Served With Roti/Naan',
          "imgSrc" : "https://static.sooperchef.pk/topics/2018/12/baingan-gosht-550x375.jpg"
        },
        {"id": "61050f21a4543be9235f4649",
        'num' : 9,
        "name": "Lahori Fish Fry",
        "type": 'Dinner',
        "desc" : 'Fry Fish With Lahori Taste Served for 4 people with Raita',
        "imgSrc" : "https://static.sooperchef.pk/topics/2018/11/lahori-fish-fry-550x375.jpg"
      },

      {"id": "61050f21a4543be9235f4648",
      'num' : 10,
      "name": "Beef Pulao",
      "type": 'Dinner',
      "desc" : 'Platter Of Beef Pulao Served with Raita and Cold Drink',
      "imgSrc" : "https://static.sooperchef.pk/topics/2018/04/Beef-Pulao-Recipe-550x375.png"
    }
    ];